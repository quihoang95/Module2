1.Tên Dự Án: LAYMY SHOP
</br>
2.Các ngôn ngữ công nghệ sử dụng:
<ul>
  <li>HTML</li>
  <li>JAVASCRIPT</li>
  <li>CSS</li>
  <li>PHP</li>
</ul>
3.Các chức năng chính:
<h3>Admin</h3>
<ul>
  <li>Add</li>
  <li>Edit</li>
  <li>Delete</li>
  <li>Log in/Log out</li>
  <li>Biết được số lượng hàng đã bán, còn tồn kho, và doanh thu 1 ngày</li>
</ul>
<hr>
<h3>Customers</h3>
<ul>
  <li>Xem hàng</li>
  <li>Mua hàng</li>
  <li>Thêm vào giỏ hàng</li>
  <li>Log in/ log out</li>
</ul>
4. Database
<h4>Ảnh ERD</h4>
<img src="https://github.com/quihoang95/Module2/blob/main/CaseStudy/img/ERD.JPG">
