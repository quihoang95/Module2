<?php 
    include "libraries/database.php";
    include "layout/header.php"; 
?>
    <div class="done">
        <div class="container text-center">
            <div class="col12">
                <div class="gif">
                <img src="https://media.giphy.com/media/cmCHuk53AiTmOwBXlw/source.gif" alt="" style="width:50%">
                </div>
                <div class="text-center">
                    <h5>ĐẶT HÀNG THÀNH CÔNG
                        <hr>
                    </h5>
                    <p>Cảm ơn bạn đã cho chúng tôi cơ hội được phục vụ!</p>
                    <p>Chúng tôi sẽ liên hệ với bạn trong vòng <b>15 phút</b> và cam kết giao hàng <b>miễn phí</b></p>
                    <a href="home.php" style="text-decoration: none; color:brown">Quay lại trang chủ</a>
                </div>
            </div>
        </div>
    </div>


    <?php include "layout/footer.php"?>